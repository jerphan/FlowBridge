"""Unresolved dynamic call: should be diagnosed, not linked to arbitrary function."""

def invoke_dynamic(function_name, payload):
    selected = globals().get(function_name)
    if selected is None:
        return "not found"
    return selected(payload)
