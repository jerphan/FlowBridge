"""Multiple imported values, function calls in conditionals."""
from core.math_ops import classify_number as classify


def create_report(first, second, third, fourth):
    summary = {"items": first, "workflow": second}
    if third == "ok":
        summary["recovery"] = "success"
    else:
        summary["recovery"] = "failed"
    summary["number"] = classify(fourth)
    return summary
