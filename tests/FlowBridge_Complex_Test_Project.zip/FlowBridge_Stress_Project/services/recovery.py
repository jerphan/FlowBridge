"""Retry loops, exceptions, and local function call expansion."""

def unstable_operation(attempt):
    if attempt < 2:
        raise OSError("temporary failure")
    return "ok"


def retry_operation(max_attempts):
    attempts = 0
    while attempts < max_attempts:
        try:
            result = unstable_operation(attempts)
        except OSError:
            attempts += 1
            continue
        else:
            return result
        finally:
            attempts += 0
    return "failed"


def mutual_a(depth):
    if depth <= 0:
        return 0
    return mutual_b(depth - 1)


def mutual_b(depth):
    if depth <= 0:
        return 0
    return mutual_a(depth - 1)
