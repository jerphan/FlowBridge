"""Cross-file imports, local helper calls, and try/finally."""
from core.math_ops import accumulate, countdown
from core.validation import ensure_nonnegative as check_value
from core.edge_conditions import nested_loop_handlers


def format_status(number):
    if number == 0:
        return "empty"
    return "nonempty"


def run_workflow(values):
    try:
        total = accumulate(values)
        status = format_status(total)
        check_value(total)
        trace = nested_loop_handlers([[1, 0], [None, 4]])
    except ValueError:
        status = "failed"
        trace = []
    finally:
        countdown(4)
    return (status, trace)
