"""INTENTIONAL UNSUPPORTED FEATURE: class and instantiated object."""
from core.math_ops import safe_divide

class CalculationEngine:
    def __init__(self, scale):
        self.scale = scale

    def calculate(self, x, y):
        try:
            return safe_divide(x, y) * self.scale
        except ZeroDivisionError:
            return None


def use_object():
    engine = CalculationEngine(2)
    return engine.calculate(10, 5)

if __name__ == "__main__":
    print(use_object())
