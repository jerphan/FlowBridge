"""Import alias and module-qualified call resolution."""
import core.math_ops as math_module
from core import validation as val


def run_aliases():
    left = math_module.safe_divide(8, 2)
    right = val.parse_integer("12")
    return left + right
