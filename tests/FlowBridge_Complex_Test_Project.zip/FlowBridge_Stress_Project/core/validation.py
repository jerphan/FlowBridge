"""Local calls, raise, multiple exception types."""

def parse_integer(raw):
    text = raw.strip()
    if text == "":
        raise ValueError("empty")
    try:
        result = int(text)
    except (TypeError, ValueError) as exc:
        raise ValueError("not an integer") from exc
    return result


def ensure_nonnegative(number):
    if number < 0:
        raise ValueError("negative values are forbidden")
    return number


def local_wrapper(raw):
    value = parse_integer(raw)
    return ensure_nonnegative(value)
