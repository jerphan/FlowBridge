"""Branches, loops, recursion and exceptions."""
from core.validation import ensure_nonnegative


def safe_divide(numerator, denominator):
    if denominator == 0:
        raise ZeroDivisionError("denominator is zero")
    return numerator / denominator


def classify_number(value):
    if value < 0:
        return "negative"
    elif value == 0:
        return "zero"
    elif value < 10:
        return "small"
    else:
        return "large"


def recursive_sum(n):
    if n <= 0:
        return 0
    return n + recursive_sum(n - 1)


def accumulate(values):
    total = 0
    for value in values:
        try:
            ensure_nonnegative(value)
        except ValueError:
            continue
        total += value
        if total > 20:
            break
    else:
        total += 1
    return total


def countdown(limit):
    while limit > 0:
        limit -= 1
        if limit == 2:
            continue
        if limit == 1:
            break
    else:
        return "finished normally"
    return "stopped"
