"""Nested try blocks, else, finally, and handlers inside loops."""
from core.validation import parse_integer


def deeply_nested(raw_items):
    output = []
    for raw in raw_items:
        try:
            try:
                value = parse_integer(raw)
                if value == 7:
                    raise RuntimeError("special case")
            except ValueError:
                value = 0
            else:
                value += 1
            finally:
                output.append("inner-finally")
        except RuntimeError as exc:
            output.append("runtime-error")
        else:
            output.append(value)
        finally:
            output.append("outer-finally")
    return output


def exception_in_finally(should_fail):
    try:
        if should_fail:
            raise ValueError("from try")
        return "success"
    finally:
        if should_fail:
            raise RuntimeError("from finally")


def except_with_return(value):
    try:
        return 5 // value
    except ZeroDivisionError:
        return -1
    finally:
        pass
