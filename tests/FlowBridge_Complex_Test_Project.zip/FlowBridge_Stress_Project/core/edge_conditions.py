"""Try/except outside functions and layered control flow."""
from core.nested_exceptions import deeply_nested

MODULE_STATE = "starting"
try:
    MODULE_VALUE = 12 // 3
except ZeroDivisionError:
    MODULE_VALUE = -1
else:
    MODULE_STATE = "ready"
finally:
    MODULE_FINISHED = True


def nested_loop_handlers(grid):
    observed = []
    for row in grid:
        for item in row:
            try:
                if item is None:
                    raise TypeError("missing")
                if item < 0:
                    continue
                observed.append(10 // item)
            except ZeroDivisionError:
                observed.append(0)
            except TypeError:
                break
            finally:
                observed.append("checked")
    return observed


def call_imported_nested():
    return deeply_nested(["1", "wrong", "7"])
