"""Unconnected file: should still be shown in project graph."""

def lonely_function():
    return "no import edges"
