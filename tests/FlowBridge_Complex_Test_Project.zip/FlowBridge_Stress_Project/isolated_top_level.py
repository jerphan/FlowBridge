"""No function definitions: module-level assignments, condition, loop, try."""
items = [1, 2, 0, 4]
accumulated = 0
for item in items:
    try:
        accumulated += 8 // item
    except ZeroDivisionError:
        accumulated += 0
    finally:
        pass
if accumulated > 10:
    outcome = "big"
else:
    outcome = "small"
