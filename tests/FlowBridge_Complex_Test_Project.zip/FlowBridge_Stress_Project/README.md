# FlowBridge Multi-File Exception & Navigation Stress Project

This is a synthetic test repository, not production application code.
All `.py` files are syntactically valid. One file deliberately contains
unsupported classes and object construction to exercise your feature validator.

## What to inspect

- **Project view:** edges from importing file to imported project file;
  repeated imports should not duplicate file nodes. `orphan_file.py` has no
  imports and should still appear. Packages have `__init__.py` files.
- **File view:** top-level statements in `main.py`, `isolated_top_level.py`,
  and `core/edge_conditions.py` should be represented accurately. Definitions
  must not be treated as automatically executed function calls.
- **Same-file calls:** `main.main() -> main.bootstrap()`;
  `services/recovery.retry_operation() -> unstable_operation()`;
  `services/workflow.run_workflow() -> format_status()`.
- **Cross-file calls:** `main.py -> core/math_ops.py`, `main.py ->
  services/workflow.py`, and multiple other imports should become navigable
  call nodes (not inline expansions in the caller's file view).
- **Exceptions:** `try/except/else/finally`, multiple except branches, tuple
  handlers, exception aliases, chained raises, nested try blocks, handling
  within functions and at module level, returns in try and except, breaks and
  continues in try, exceptions in finally.
- **Recursion:** `recursive_sum()` calls itself, `mutual_a()` and `mutual_b()`
  call one another. Expanding same-file CFGs must terminate.
- **Imports:** `from ... import ...`, `import ... as ...`, imported function
  aliases, and module-qualified calls.
- **Unsupported classes:** `services/unsupported_classes.py` contains a class,
  method, `self`, and object instantiation. This should yield a useful
  UNSUPPORTED_FEATURE diagnostic if classes are out of scope. The entire
  project may be rejected by a strict whole-project validator; inspect the
  diagnostic and test the other files independently when needed.
- **Unresolved calls:** `services/unresolved_calls.py` contains dynamic call
  lookup, which a static analysis engine should not pretend to resolve.
- **Syntax errors:** `errors_and_unsupported.txt` contains invalid Python to
  opt into separately; intentionally not named `.py` to keep this project
  syntactically valid until you want a syntax-error test.

## Suggested test order

1. Upload the full ZIP and verify file dependency links, diagnostics, source
   mappings, and behavior for unsupported class syntax.
2. If your validator rejects the whole ZIP because of class syntax, remove
   `services/unsupported_classes.py` and ZIP the project again to test graphs.
3. Analyze `isolated_top_level.py` on its own to verify top-level CFGs.
4. Analyze `core/nested_exceptions.py` on its own to verify exception CFGs.
5. Copy the snippet from `errors_and_unsupported.txt` into `bad_syntax.py`,
   then verify a syntax diagnostic is returned without a server crash.

## Important notes

- Python exception control flow is subtle: `finally` runs during normal exits,
  returns, break/continue, and exceptions, including exceptions raised inside
  `finally` itself. Verify the graph reflects this if supported.
- Static import edges are *dependencies*, not proof that a function is called.
- Module-level import/statement execution may need synthetic module CFGs.
- Function graph selection should use stable graph IDs, not function names.
- Some cases may be intentionally unsupported depending on FlowBridge scope.
