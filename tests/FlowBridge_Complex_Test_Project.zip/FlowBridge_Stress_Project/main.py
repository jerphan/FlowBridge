"""Entry point: top-level statements, imports, calls and exception paths."""
from core.math_ops import safe_divide, classify_number, recursive_sum
from core.validation import parse_integer
from services.workflow import run_workflow
from services.recovery import retry_operation
from services.reporting import create_report

APP_NAME = "FlowBridge exception stress test"


def bootstrap():
    values = ["8", "0", "bad", "-3"]
    results = []
    for raw in values:
        try:
            number = parse_integer(raw)
            score = safe_divide(100, number)
        except ValueError as exc:
            results.append((raw, "invalid"))
        except ZeroDivisionError:
            results.append((raw, "zero"))
        else:
            results.append((raw, classify_number(score)))
        finally:
            pass
    return results


def main():
    first = bootstrap()
    second = run_workflow([1, -2, 0, 3])
    third = retry_operation(3)
    fourth = recursive_sum(4)
    return create_report(first, second, third, fourth)


if __name__ == "__main__":
    print(main())
